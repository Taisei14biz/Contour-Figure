@echo off
rem ============================================================
rem  Contour Maker - EXE build script  (fully automatic)
rem  Requirement: Python 3.9+ on PATH. Nothing else.
rem  Double-click this file. Output: dist\ContourMaker.exe
rem ============================================================
cd /d %~dp0

echo [1/2] Installing required libraries (automatic)...
python -m pip install --upgrade pip
python -m pip install numpy matplotlib PySide6 pyinstaller imageio-ffmpeg
if errorlevel 1 goto :error

echo [2/2] Building EXE (this may take a few minutes)...
python -m PyInstaller --onefile --windowed --name ContourMaker ^
  --hidden-import matplotlib.backends.backend_qtagg ^
  --collect-all imageio_ffmpeg ^
  --exclude-module tkinter ^
  contour_maker.py
if errorlevel 1 goto :error

echo Done!
echo.
echo   dist\ContourMaker.exe has been created.
echo   - Double-click the EXE  : GUI mode (animation player included)
echo   - Drag and drop .dat onto the EXE icon :
echo       1 zone  -^> PNG,  multiple zones -^> MP4 (auto)
echo   - You can also drop .dat files onto the GUI window
echo.
pause
exit /b 0

:error
echo.
echo *** ERROR: Build failed. ***
echo Please check that Python is installed and added to PATH.
echo If pip failed, check your internet connection or proxy.
echo.
pause
exit /b 1
