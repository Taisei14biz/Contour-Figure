# -*- coding: utf-8 -*-
"""
Contour Maker (PySide6版 / アニメーション対応)
==============================================
Tecplot形式の DAT ファイルを読み込み、コンター図を自動生成するツール。
複数ゾーン(solutiontime付き)のファイルはアニメーションとして再生・MP4保存可能。

使い方:
  1) GUI モード      : そのまま起動してファイルを選択
  2) ドラッグ&ドロップ: EXE アイコンに .dat を重ねると自動で
                        PNG(1ゾーン) / MP4(複数ゾーン) を生成
  3) コマンドライン   : ContourMaker.exe file1.dat file2.dat ...

DATファイルのルール:
  1行目: title="..."
  2行目: variables="x","y","p",...
  3行目: zone, i = NI, j = NJ f=point   (格子サイズ)
  4行目以降: 数値データ (カンマ・空白区切り)
  ※ アニメーション用: zone T="...", solutiontime=..., i=NI, j=NJ
     というゾーンブロックの繰り返しに対応 (ヘッダーが複数行でも可)
"""

import os
import re
import sys
import traceback

import numpy as np
import matplotlib
from matplotlib.figure import Figure

# ffmpeg (MP4書き出し用) : imageio-ffmpeg 同梱バイナリを優先使用
try:
    import imageio_ffmpeg
    matplotlib.rcParams["animation.ffmpeg_path"] = \
        imageio_ffmpeg.get_ffmpeg_exe()
    HAS_FFMPEG = True
except Exception:
    HAS_FFMPEG = False

# 数値だけの行かどうかの判定 (e/E以外のアルファベットや"や=を含めばヘッダー候補)
_HEADER_RE = re.compile(r'[a-df-zA-DF-Z"=]')
# 本物のヘッダーが含むキーワード (これが無い行は壊れた数値行とみなす)
_KEYWORD_RE = re.compile(
    r'zone|variables|title|strandid|solutiontime|f\s*=|[ij]\s*=\s*\d+',
    re.IGNORECASE)


# ----------------------------------------------------------------------
# DAT ファイル読み込み部
# ----------------------------------------------------------------------
class Frame:
    """1ゾーン(=1コマ)分のデータ"""
    def __init__(self, arrays, time=None, name=""):
        self.arrays = arrays      # 変数名 -> 2次元配列
        self.time = time          # solutiontime (無ければ None)
        self.name = name          # zone T="..."


class TecplotData:
    """Tecplot POINT 形式 (単一/複数ゾーン) のデータを保持するクラス。
    破損データ(文字化け・NUL混入・引用符欠け等)に耐性あり:
      - 壊れた数値は NaN にして周囲の格子点から補間修復
      - 修復できないゾーンはスキップして続行
      - 処理内容は .warnings に記録される
    """

    def __init__(self, path):
        self.path = path
        self.title = os.path.splitext(os.path.basename(path))[0]
        self.variables = []
        self.ni = None
        self.nj = None
        self.frames = []          # Frame のリスト (時系列順)
        self.warnings = []        # 読み込み時の警告メッセージ
        self._ref_map = None      # 座標(x,y) -> ファイル内位置 (修復用)
        self._ref_xy = None       # 参照フレームの座標そのもの
        self._load()

    # 互換用: 最初のフレームの配列
    @property
    def arrays(self):
        return self.frames[0].arrays

    @property
    def nframes(self):
        return len(self.frames)

    # ------------------------------------------------------------------
    @staticmethod
    def _parse_variables(line):
        """variables= 行の解析 (引用符が欠けていても耐える)"""
        rhs = line.split("=", 1)[1] if "=" in line else line
        names = [t.strip().strip('"').strip() for t in rhs.split(",")]
        return [n for n in names if n]

    @staticmethod
    def _parse_block_fast(zlines, nvar):
        """ゾーンの数値行をまとめて高速変換。失敗したら None"""
        blob = " ".join(zlines).replace(",", " ")
        try:
            import warnings as _w
            with _w.catch_warnings():
                _w.simplefilter("ignore")
                arr = np.fromstring(blob, sep=" ")
        except Exception:
            return None
        if arr.size == len(zlines) * nvar:
            return arr.reshape(len(zlines), nvar)
        return None

    @staticmethod
    def _parse_block_tolerant(zlines, nvar):
        """1行ずつ検査しながら変換。壊れた値は NaN。戻り値: (配列, 不良点数)"""
        out = np.full((len(zlines), nvar), np.nan)
        bad = 0
        for r, line in enumerate(zlines):
            toks = [t for t in re.split(r"[,\s]+", line) if t]
            c = 0
            for t in toks:
                if c >= nvar:
                    break
                try:
                    out[r, c] = float(t)
                except ValueError:
                    pass          # NaN のまま
                c += 1
            if np.isnan(out[r]).any():
                bad += 1
        return out, bad

    @staticmethod
    def _fill_nan(a, max_iter=100):
        """NaN を上下左右の平均で埋める (反復)。戻り値: (配列, 残NaN数)"""
        import warnings as _w
        a = a.copy()
        for _ in range(max_iter):
            mask = np.isnan(a)
            if not mask.any():
                break
            p = np.pad(a, 1, constant_values=np.nan)
            with _w.catch_warnings():
                _w.simplefilter("ignore")
                neigh = np.nanmean(
                    np.stack([p[:-2, 1:-1], p[2:, 1:-1],
                              p[1:-1, :-2], p[1:-1, 2:]]), axis=0)
            a[mask] = neigh[mask]
        return a, int(np.isnan(a).sum())

    # ------------------------------------------------------------------
    def _finalize_zone(self, zinfo, zlines, nvar):
        """1ゾーン分の数値行を配列化して frames に追加。
        破損ゾーンは正常フレームの格子座標と照合して再構成する。"""
        ni, nj, time, name, zidx = zinfo
        npts = ni * nj

        block = None
        note = ""

        # --- 正常ケース: 行数一致 + 一括変換成功 ---
        if len(zlines) == npts:
            block = self._parse_block_fast(zlines, nvar)

        # --- 破損ケース: 1行ずつ許容パース + 座標照合で再構成 ---
        if block is None:
            parsed, bad = self._parse_block_tolerant(zlines, nvar)
            if self._ref_map is not None:
                rebuilt = np.full((npts, nvar), np.nan)
                matched = 0
                for row in parsed:
                    if np.isnan(row[0]) or np.isnan(row[1]):
                        continue
                    pos = self._ref_map.get(
                        (round(float(row[0]), 6), round(float(row[1]), 6)))
                    if pos is not None:
                        rebuilt[pos] = row
                        matched += 1
                if matched >= npts * 0.95:
                    rebuilt[:, 0:2] = self._ref_xy   # 座標は参照格子で確定
                    block = rebuilt
                    miss = npts - matched
                    note = (f"破損データを座標照合で再構成 "
                            f"(欠損 {miss}点は補間)")
                else:
                    self.warnings.append(
                        f'ゾーン{zidx} (T="{name}"): 破損が大きく再構成不能'
                        f"のためスキップ (一致 {matched}/{npts}点)")
                    return
            else:
                # 参照格子がまだ無い場合は従来の方法
                if len(zlines) != npts or bad > npts * 0.05:
                    self.warnings.append(
                        f'ゾーン{zidx} (T="{name}"): 破損のためスキップ '
                        f"({len(zlines)}/{npts}行, 不良{bad}点)")
                    return
                block = parsed
                if bad:
                    note = f"破損 {bad}点 を補間修復"

        arrays = {}
        x = block[:, 0]
        head = x[: nj]
        valid = head[~np.isnan(head)]
        j_inner = valid.size > 0 and np.allclose(valid, valid[0])
        remain_total = 0
        for k, vname in enumerate(self.variables):
            col = block[:, k]
            grid = col.reshape(ni, nj) if j_inner \
                else col.reshape(nj, ni).T
            if np.isnan(grid).any():
                grid, remain = self._fill_nan(grid)
                remain_total += remain
            arrays[vname] = grid

        if remain_total:
            self.warnings.append(
                f'ゾーン{zidx} (T="{name}"): 補間しきれない欠損が残存 '
                f"({remain_total}点)")
        elif note:
            self.warnings.append(f'ゾーン{zidx} (T="{name}"): {note}')

        # 最初の正常ゾーンから座標マップを作成 (静止格子の修復に使用)
        if self._ref_map is None and not np.isnan(block[:, :2]).any():
            self._ref_map = {
                (round(float(px), 6), round(float(py), 6)): idx
                for idx, (px, py) in enumerate(block[:, :2])}
            self._ref_xy = block[:, :2].copy()

        self.ni, self.nj = ni, nj
        self.frames.append(Frame(arrays, time, name))

    # ------------------------------------------------------------------
    def _load(self):
        pending = ""              # 解析中の zone ヘッダー
        cur_zone = None           # (ni, nj, time, name, zidx)
        cur_lines = []            # 現在のゾーンの数値行
        nvar = None
        zidx = 0

        def close_current():
            nonlocal cur_zone, cur_lines, nvar
            if cur_zone is None or not cur_lines:
                cur_lines = []
                return
            if nvar is None:
                first = cur_lines[0]
                n = len([t for t in re.split(r"[,\s]+", first) if t])
                nvar = n
                if len(self.variables) != n:
                    self.variables = (self.variables +
                                      [f"v{k}" for k in range(n)])[:n]
            self._finalize_zone(cur_zone, cur_lines, nvar)
            cur_lines = []

        with open(self.path, "r", encoding="utf-8",
                  errors="replace") as f:
            for line in f:
                s = line.strip().replace("\x00", "")
                if not s:
                    continue
                if _HEADER_RE.search(s) and _KEYWORD_RE.search(s):  # ヘッダー行
                    m = re.search(r'title\s*=\s*"([^"]*)"', s,
                                  re.IGNORECASE)
                    if m and not self.frames:
                        self.title = m.group(1)
                        continue
                    if re.match(r"\s*variables", s, re.IGNORECASE):
                        if not self.variables:
                            self.variables = self._parse_variables(s)
                        continue
                    pending += " " + s
                    mi = re.search(r"\bi\s*=\s*(\d+)", pending,
                                   re.IGNORECASE)
                    mj = re.search(r"\bj\s*=\s*(\d+)", pending,
                                   re.IGNORECASE)
                    if mi and mj and re.search(r"\bzone\b", pending,
                                               re.IGNORECASE):
                        close_current()           # 前のゾーンを確定
                        mt = re.search(
                            r"solutiontime\s*=\s*([0-9.eEdD+\-]+)",
                            pending, re.IGNORECASE)
                        time = None
                        if mt:
                            try:
                                time = float(mt.group(1)
                                             .replace("D", "E")
                                             .replace("d", "e"))
                            except ValueError:
                                pass
                        mn = re.search(r'\bT\s*=\s*"([^"]*)"', pending)
                        name = mn.group(1).strip() if mn else ""
                        zidx += 1
                        cur_zone = (int(mi.group(1)), int(mj.group(1)),
                                    time, name, zidx)
                        pending = ""
                else:                             # 数値行
                    cur_lines.append(s)

        close_current()                            # 最終ゾーン

        if not self.frames:
            detail = "\n".join(self.warnings[-5:])
            raise ValueError(
                "有効なゾーンデータが読み込めませんでした。\n" + detail)

    def global_range(self, var_name):
        """全フレームを通した最小・最大 (アニメの色を固定するため)"""
        vmin = min(np.nanmin(f.arrays[var_name]) for f in self.frames)
        vmax = max(np.nanmax(f.arrays[var_name]) for f in self.frames)
        return vmin, vmax


# ----------------------------------------------------------------------
# 描画部
# ----------------------------------------------------------------------
def nice_levels(vmin, vmax, target=11):
    """キリの良い間隔でコンターレベルを作る"""
    span = vmax - vmin
    if span <= 0:
        return np.linspace(vmin - 0.5, vmax + 0.5, 3)
    raw = span / max(target - 1, 1)
    mag = 10.0 ** np.floor(np.log10(raw))
    for step in (1, 2, 2.5, 5, 10):
        if raw <= step * mag:
            raw = step * mag
            break
    lo = np.floor(vmin / raw) * raw
    hi = np.ceil(vmax / raw) * raw
    return np.arange(lo, hi + raw * 0.5, raw)


def draw_contour(fig, tec, var_name, frame_idx=0, levels=None, cmap="jet",
                 mode="filled", edge=True):
    """Figure にコンター図を描く
    mode: "filled"=塗りつぶし, "lines"=等高線, "both"=両方
    edge: True なら計算領域の外周(格子の縁)を黒線で描く"""
    fig.clf()
    ax = fig.add_subplot(111)

    fr = tec.frames[frame_idx]
    xname, yname = tec.variables[0], tec.variables[1]
    X = fr.arrays[xname]
    Y = fr.arrays[yname]
    Z = fr.arrays[var_name]

    if levels is None:
        levels = nice_levels(*tec.global_range(var_name))

    if mode in ("filled", "both"):
        cf = ax.contourf(X, Y, Z, levels=levels, cmap=cmap, extend="both")
        cbar = fig.colorbar(cf, ax=ax, ticks=levels)
    if mode in ("lines", "both"):
        lc = "black" if mode == "both" else None
        cs = ax.contour(X, Y, Z, levels=levels,
                        colors=lc, cmap=None if lc else cmap,
                        linewidths=0.6 if lc else 1.2)
        if mode == "lines":
            cbar = fig.colorbar(cs, ax=ax, ticks=levels)
            ax.clabel(cs, inline=True, fontsize=7, fmt="%g")
    cbar.set_label(var_name, fontsize=12, rotation=0, labelpad=12)

    if edge:
        # 格子の外周4辺 (i=0, i=末端, j=0, j=末端) を黒線で描く
        for xe, ye in ((X[0, :], Y[0, :]), (X[-1, :], Y[-1, :]),
                       (X[:, 0], Y[:, 0]), (X[:, -1], Y[:, -1])):
            ax.plot(xe, ye, color="black", linewidth=1.2, zorder=5)

    title = tec.title
    if fr.time is not None:
        title += f"   t = {fr.time:.4f}"
    elif tec.nframes > 1:
        title += f"   frame {frame_idx}"
    ax.set_title(title, fontsize=12)

    ax.set_xlabel(xname, fontsize=13, fontweight="bold")
    ax.set_ylabel(yname, fontsize=13, fontweight="bold")
    ax.set_aspect("equal", adjustable="box")
    fig.tight_layout()
    return ax


def save_mp4(tec, out_path, var_name=None, levels=None, cmap="jet",
             mode="filled", edge=True, fps=10, dpi=120, progress=None):
    """全フレームを MP4 に書き出す。progress: callback(i, n) -> 続行ならTrue"""
    from matplotlib.animation import FFMpegWriter
    if var_name is None:
        var_name = tec.variables[-1]
    if levels is None:
        levels = nice_levels(*tec.global_range(var_name))

    fig = Figure(figsize=(8, 6), dpi=dpi)
    writer = FFMpegWriter(fps=fps, bitrate=3000)
    with writer.saving(fig, out_path, dpi=dpi):
        for i in range(tec.nframes):
            draw_contour(fig, tec, var_name, frame_idx=i,
                         levels=levels, cmap=cmap, mode=mode, edge=edge)
            writer.grab_frame()
            if progress and not progress(i + 1, tec.nframes):
                break
    return out_path


def dat_to_media(dat_path, var_name=None, fps=10, warn_out=None):
    """DAT → PNG(1フレーム) / MP4(複数フレーム) を自動生成"""
    tec = TecplotData(dat_path)
    if warn_out is not None:
        warn_out.extend(tec.warnings)
    if var_name is None:
        var_name = tec.variables[-1]
    base = os.path.splitext(dat_path)[0]
    if tec.nframes <= 1:
        fig = Figure(figsize=(8, 6), dpi=150)
        draw_contour(fig, tec, var_name)
        out = f"{base}_{var_name}.png"
        fig.savefig(out, dpi=150, bbox_inches="tight")
    else:
        out = f"{base}_{var_name}.mp4"
        save_mp4(tec, out, var_name=var_name, fps=fps)
    return out


# ----------------------------------------------------------------------
# GUI 部 (PySide6)
# ----------------------------------------------------------------------
def run_gui(initial_files=None):
    matplotlib.use("QtAgg")
    from PySide6.QtCore import Qt, QTimer
    from PySide6.QtWidgets import (
        QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
        QPushButton, QComboBox, QLabel, QLineEdit, QCheckBox, QSlider,
        QSpinBox, QFileDialog, QMessageBox, QStatusBar, QProgressDialog)
    from matplotlib.backends.backend_qtagg import (
        FigureCanvasQTAgg, NavigationToolbar2QT)

    MODE_NAMES = [("塗りつぶし", "filled"),
                  ("等高線", "lines"),
                  ("塗りつぶし+等高線", "both")]

    class MainWindow(QMainWindow):
        def __init__(self):
            super().__init__()
            self.setWindowTitle("Contour Maker  -  DAT → コンター図/アニメーション")
            self.resize(1050, 850)
            self.setAcceptDrops(True)
            self.tec = None
            self.playing = False
            self.timer = QTimer(self)
            self.timer.timeout.connect(self.next_frame)

            central = QWidget()
            self.setCentralWidget(central)
            vbox = QVBoxLayout(central)

            # ---------- 上段コントロール ----------
            bar = QHBoxLayout()
            btn_open = QPushButton("DATファイルを開く")
            btn_open.clicked.connect(self.open_file)
            bar.addWidget(btn_open)

            bar.addWidget(QLabel("変数:"))
            self.var_box = QComboBox()
            self.var_box.currentIndexChanged.connect(
                lambda _: self.auto_levels())
            bar.addWidget(self.var_box)

            bar.addWidget(QLabel("表示:"))
            self.mode_box = QComboBox()
            self.mode_box.addItems([n for n, _ in MODE_NAMES])
            self.mode_box.currentIndexChanged.connect(
                lambda _: self.redraw())
            bar.addWidget(self.mode_box)

            self.chk_edge = QCheckBox("エッジ(黒枠)")
            self.chk_edge.setChecked(True)
            self.chk_edge.stateChanged.connect(lambda _: self.redraw())
            bar.addWidget(self.chk_edge)

            bar.addWidget(QLabel("カラーマップ:"))
            self.cmap_box = QComboBox()
            self.cmap_box.addItems(["jet", "viridis", "rainbow",
                                    "coolwarm", "turbo", "plasma"])
            self.cmap_box.currentIndexChanged.connect(
                lambda _: self.redraw())
            bar.addWidget(self.cmap_box)

            bar.addStretch(1)
            btn_png = QPushButton("PNG保存")
            btn_png.clicked.connect(self.save_png)
            bar.addWidget(btn_png)
            self.btn_mp4 = QPushButton("MP4保存")
            self.btn_mp4.clicked.connect(self.save_mp4)
            bar.addWidget(self.btn_mp4)
            vbox.addLayout(bar)

            # ---------- レベル設定 ----------
            bar2 = QHBoxLayout()
            bar2.addWidget(QLabel("レベル  最小:"))
            self.lv_min = QLineEdit(); self.lv_min.setFixedWidth(80)
            bar2.addWidget(self.lv_min)
            bar2.addWidget(QLabel("最大:"))
            self.lv_max = QLineEdit(); self.lv_max.setFixedWidth(80)
            bar2.addWidget(self.lv_max)
            bar2.addWidget(QLabel("間隔:"))
            self.lv_step = QLineEdit(); self.lv_step.setFixedWidth(80)
            bar2.addWidget(self.lv_step)
            btn_apply = QPushButton("適用")
            btn_apply.clicked.connect(self.redraw)
            bar2.addWidget(btn_apply)
            btn_auto = QPushButton("自動")
            btn_auto.clicked.connect(self.auto_levels)
            bar2.addWidget(btn_auto)
            bar2.addStretch(1)
            vbox.addLayout(bar2)

            # ---------- アニメーション操作 ----------
            bar3 = QHBoxLayout()
            self.btn_play = QPushButton("▶ 再生")
            self.btn_play.clicked.connect(self.toggle_play)
            bar3.addWidget(self.btn_play)
            self.slider = QSlider(Qt.Horizontal)
            self.slider.setMinimum(0)
            self.slider.valueChanged.connect(self.on_slider)
            bar3.addWidget(self.slider, stretch=1)
            self.frame_label = QLabel("frame 0/0")
            bar3.addWidget(self.frame_label)
            bar3.addWidget(QLabel("FPS:"))
            self.fps_box = QSpinBox()
            self.fps_box.setRange(1, 60)
            self.fps_box.setValue(10)
            self.fps_box.valueChanged.connect(self.update_timer)
            bar3.addWidget(self.fps_box)
            vbox.addLayout(bar3)

            # ---------- 描画エリア ----------
            self.fig = Figure(figsize=(8, 6), dpi=100)
            self.canvas = FigureCanvasQTAgg(self.fig)
            vbox.addWidget(self.canvas, stretch=1)
            vbox.addWidget(NavigationToolbar2QT(self.canvas, self))

            self.status = QStatusBar()
            self.setStatusBar(self.status)
            self.status.showMessage(
                "DATファイルを開くか、ここにドラッグ&ドロップしてください")
            self.set_anim_enabled(False)

        # ----- ドラッグ&ドロップ -----
        def dragEnterEvent(self, e):
            if e.mimeData().hasUrls():
                e.acceptProposedAction()

        def dropEvent(self, e):
            for url in e.mimeData().urls():
                p = url.toLocalFile()
                if p.lower().endswith(".dat"):
                    self.load(p)
                    break

        # --------------------------------------------------------------
        def set_anim_enabled(self, on):
            for w in (self.btn_play, self.slider,
                      self.fps_box, self.btn_mp4):
                w.setEnabled(on)

        def open_file(self):
            path, _ = QFileDialog.getOpenFileName(
                self, "Tecplot DATファイルを選択", "",
                "DAT files (*.dat);;All files (*.*)")
            if path:
                self.load(path)

        def load(self, path):
            self.stop_play()
            self.status.showMessage("読み込み中...")
            QApplication.processEvents()
            try:
                self.tec = TecplotData(path)
            except Exception as e:
                QMessageBox.critical(self, "読み込みエラー", str(e))
                self.status.showMessage("読み込み失敗")
                return
            plot_vars = self.tec.variables[2:] or self.tec.variables
            self.var_box.blockSignals(True)
            self.var_box.clear()
            self.var_box.addItems(plot_vars)
            self.var_box.setCurrentIndex(len(plot_vars) - 1)
            self.var_box.blockSignals(False)

            n = self.tec.nframes
            self.slider.blockSignals(True)
            self.slider.setMaximum(max(n - 1, 0))
            self.slider.setValue(0)
            self.slider.blockSignals(False)
            self.set_anim_enabled(n > 1)

            self.auto_levels()
            self.status.showMessage(
                f"{os.path.basename(path)}   i={self.tec.ni}, "
                f"j={self.tec.nj}   フレーム数: {n}   "
                f"変数: {', '.join(self.tec.variables)}")
            if self.tec.warnings:
                shown = self.tec.warnings[:15]
                extra = len(self.tec.warnings) - len(shown)
                msg = "\n".join(shown)
                if extra > 0:
                    msg += f"\n... 他 {extra} 件"
                QMessageBox.information(
                    self, "読み込み時の注意",
                    "一部のデータに破損があり、自動修復しました:\n\n" + msg)

        # ----- レベル -----
        def auto_levels(self):
            if self.tec is None:
                return
            lv = nice_levels(
                *self.tec.global_range(self.var_box.currentText()))
            self.lv_min.setText(f"{lv[0]:g}")
            self.lv_max.setText(f"{lv[-1]:g}")
            self.lv_step.setText(f"{lv[1] - lv[0]:g}")
            self.redraw()

        def get_levels(self):
            try:
                lo = float(self.lv_min.text())
                hi = float(self.lv_max.text())
                st = float(self.lv_step.text())
                if st > 0 and hi > lo:
                    return np.arange(lo, hi + st * 0.5, st)
            except ValueError:
                pass
            return None

        def get_mode(self):
            return MODE_NAMES[self.mode_box.currentIndex()][1]

        # ----- 描画 -----
        def redraw(self):
            if self.tec is None:
                return
            try:
                draw_contour(self.fig, self.tec,
                             self.var_box.currentText(),
                             frame_idx=self.slider.value(),
                             levels=self.get_levels(),
                             cmap=self.cmap_box.currentText(),
                             mode=self.get_mode(),
                             edge=self.chk_edge.isChecked())
                self.canvas.draw()
                self.frame_label.setText(
                    f"frame {self.slider.value()}/{self.tec.nframes - 1}")
            except Exception:
                QMessageBox.critical(self, "描画エラー",
                                     traceback.format_exc())

        # ----- アニメーション -----
        def on_slider(self, _):
            self.redraw()

        def toggle_play(self):
            if self.playing:
                self.stop_play()
            else:
                self.playing = True
                self.btn_play.setText("■ 停止")
                self.update_timer()

        def stop_play(self):
            self.playing = False
            self.btn_play.setText("▶ 再生")
            self.timer.stop()

        def update_timer(self):
            if self.playing:
                self.timer.start(int(1000 / self.fps_box.value()))

        def next_frame(self):
            if self.tec is None:
                return
            nxt = (self.slider.value() + 1) % self.tec.nframes
            self.slider.setValue(nxt)   # → on_slider → redraw

        # ----- 保存 -----
        def save_png(self):
            if self.tec is None:
                return
            default = os.path.splitext(self.tec.path)[0] + \
                f"_{self.var_box.currentText()}.png"
            path, _ = QFileDialog.getSaveFileName(
                self, "PNG保存", default, "PNG (*.png)")
            if path:
                self.fig.savefig(path, dpi=200, bbox_inches="tight")
                self.status.showMessage(f"保存しました: {path}")

        def save_mp4(self):
            if self.tec is None or self.tec.nframes <= 1:
                return
            default = os.path.splitext(self.tec.path)[0] + \
                f"_{self.var_box.currentText()}.mp4"
            path, _ = QFileDialog.getSaveFileName(
                self, "MP4保存", default, "MP4 (*.mp4)")
            if not path:
                return
            self.stop_play()
            n = self.tec.nframes
            dlg = QProgressDialog("MP4を書き出しています...",
                                  "キャンセル", 0, n, self)
            dlg.setWindowTitle("MP4保存")
            dlg.setWindowModality(Qt.WindowModal)
            dlg.show()

            def progress(i, total):
                dlg.setValue(i)
                QApplication.processEvents()
                return not dlg.wasCanceled()

            try:
                save_mp4(self.tec, path,
                         var_name=self.var_box.currentText(),
                         levels=self.get_levels(),
                         cmap=self.cmap_box.currentText(),
                         mode=self.get_mode(),
                         edge=self.chk_edge.isChecked(),
                         fps=self.fps_box.value(),
                         progress=progress)
                dlg.setValue(n)
                if dlg.wasCanceled():
                    self.status.showMessage("MP4保存をキャンセルしました")
                else:
                    self.status.showMessage(f"保存しました: {path}")
            except Exception:
                dlg.close()
                QMessageBox.critical(self, "MP4保存エラー",
                                     traceback.format_exc())

    app = QApplication(sys.argv)
    win = MainWindow()
    win.show()
    if initial_files:
        win.load(initial_files[0])
    sys.exit(app.exec())


# ----------------------------------------------------------------------
def show_popup(msg):
    try:
        from PySide6.QtWidgets import QApplication, QMessageBox
        app = QApplication(sys.argv)
        QMessageBox.information(None, "Contour Maker", msg)
    except Exception:
        print(msg)


def main():
    args = [a for a in sys.argv[1:] if a.lower().endswith(".dat")]
    if args:
        matplotlib.use("Agg")
        ok, ng, warns = [], [], []
        for p in args:
            try:
                ok.append(dat_to_media(p, warn_out=warns))
            except Exception as e:
                ng.append(f"{p}: {e}")
        msg = ""
        if ok:
            msg += "作成しました:\n" + "\n".join(ok)
        if warns:
            msg += ("\n\n注意 (破損データを自動修復):\n" +
                    "\n".join(warns[:10]))
            if len(warns) > 10:
                msg += f"\n... 他 {len(warns)-10} 件"
        if ng:
            msg += "\n\nエラー:\n" + "\n".join(ng)
        show_popup(msg or "処理対象がありません")
    else:
        run_gui()


if __name__ == "__main__":
    main()
